<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->smallInteger('user_id');
            $table->Integer('product_id');
            $table->Integer('batch_used');
            $table->string('destination');
            $table->string('quantity');
            $table->string('remarks')->nullable();
            $table->string('invoice')->nullable();
            $table->string('delivery_note')->nullable();
            $table->string('receipt')->nullable();
            $table->tinyInteger('cash')->default(0); //Tell if the product was paid by cash
            $table->tinyInteger('approve')->default(0);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}
