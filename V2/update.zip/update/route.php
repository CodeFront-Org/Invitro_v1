
Route::resource('/cards',App\Http\Controllers\CardsController::class);