<?php $__env->startSection('content'); ?>
        <div class="row mt-1">
            <div class="col-12">
                <div class="card" style="border-radius:0px 15px 15px 15px;box-shadow: 2px 3px 3px 2px rgba(9, 107, 255, 0.179);">
                    <div class="card-body">
                    <div class="table-responsive" style="overflow-x: auto;">
                        <form action="<?php echo e(route('/complete-order')); ?>" method="POST">
                            <?php echo method_field('GET'); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product_id); ?>" />
                            <input type="hidden" name="total_quantity" value="<?php echo e($tot_qty); ?>" />
                            <input type="hidden" name="destination" value="<?php echo e($destination); ?>" />
                            <input type="hidden" name="invoice" value="<?php echo e($invoice); ?>" />
                            <input type="hidden" name="receipt" value="<?php echo e($receipt); ?>" />
                            <input type="hidden" name="d_note" value="<?php echo e($d_note); ?>" />
                            <input type="hidden" name="cash" value="<?php echo e($cash); ?>" />
                            <input type="hidden" name="remarks" value="<?php echo e($remarks); ?>" />
                        <table style="font-family: 'Times New Roman', Times, serif;" class="table table-bordered nowrap text-center" id="datatable">
                                <thead class="table-light">
                                <tr>
                                    <th>#</th>
                                    <th>Batch/Lot No:</th>
                                    <th>Available</th>
                                    <th>Used</th>
                                    <th>Remaining</th>
                                    <th>Expiry Date</th>
                                </tr>
                                </thead>


                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <input type="hidden" name="batch_id[]" value="<?php echo e($item['batch_id']); ?>" />
                                        <input type="hidden" name="data_rem[]" value="<?php echo e($item['remaining']); ?>" />

                                        <tr>
                                            <td><?php echo e($loop->index+1); ?>.</td>
                                            <td><?php echo e($item['batch_no']); ?></td>
                                            <td><?php echo e($item['quantity']); ?></td>
                                            <td><?php echo e($item['used']); ?></td>
                                            <td><?php echo e($item['remaining']); ?></td>
                                            <td><?php echo e($item['expiry_date']); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <div class="modal-footer1">
                            <button class="btn p-1" id="newbtn" style="background-color: #08228a9f;color: white" type="submit">
                                    Submit
                            </button>
                            <button class="btn p-1" id="newloader" style="background-color: #08228a9f;color: white;display:none;" type="button">
                                    <span class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>
                                    Saving Data...
                            </button>
                        </div>
                        </form>
                        </div>
                    </div>
                </div>

            </div>
        </div> <!-- end row -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
    $(document).ready(function(){
//Add newOrderForm
$("#newOrderForm").on('submit',(e)=>{
e.preventDefault();
var btn=$("#newbtn");
var loader=$("#newloader")
btn.hide();
loader.show();
let data=$("#newOrderForm").serialize();
$.ajax({
    type: "POST",
    url: "/order",
    data: data,
    success: function (response) {
console.log(response)
if(response.status===404){//Means quantity exceeded
        btn.show();
        loader.hide();
        Swal.fire("Quantity Exceeded!", "Available Qty is: "+response.quantity, "error");
        return
}
    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "5000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
    toastr["success"]("", "Order Created Succesfully.")
  
    location.href='order'

    },
    error: function(res){ console.log(res)
        btn.show();
        loader.hide();
        Swal.fire("Error!", "Try again later...", "error");
    }
});
})

// Edit settings Form
$(".settiingsEditForm").on('submit', function(e) {
  e.preventDefault();

  const form = $(this);
  var itemId = form.find('input[name="editsettingId"]').val();
  var btn = $("#editbtn" + itemId);
  var loader = $("#editloader" + itemId);
  btn.hide();
  loader.show();
  let data = form.serialize();
$.ajax({
    type: 'PATCH',
    url: '/#/' + itemId,
    data: data,
    success: function (response) { console.log(response)

                    toastr.options = {
                        "closeButton": false,
                        "debug": false,
                        "newestOnTop": false,
                        "progressBar": true,
                        "positionClass": "toast-top-right",
                        "preventDuplicates": false,
                        "onclick": null,
                        "showDuration": "300",
                        "hideDuration": "1000",
                        "timeOut": "5000",
                        "extendedTimeOut": "1000",
                        "showEasing": "swing",
                        "hideEasing": "linear",
                        "showMethod": "fadeIn",
                        "hideMethod": "fadeOut"
                    }
                    toastr["success"]("", "Settings Update Succesfully.")
        location.href='#'
    },
    error: function(res){ console.log(res)
        Swal.fire("Error!", "Try again later...", "error");
    }
});
})


    })
    </script>

    <script>

        //Deleting Settings
        function del(e){
        let id=e.value;
        var type=0;//For knowing deletion operation is coming from settings

        Swal.fire({
            title: "Confirm deletion",
            text: "You won't be able to revert this!",
            type: "error",
            showCancelButton: !0,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((t)=>{
        if(t.value){
                $.ajax({
                    type: "DELETE",
                    url: "settings/"+id,
                    data:{
                        _token:"<?php echo e(csrf_token()); ?>", id,type
                    },
                    success: function (response) { console.log(response)

                        Swal.fire("Deleted", "Successfully.", "success").then(()=>{
                        location.href='#'})
                    },
                    error: function(res){console.log(res)
                        Swal.fire("Error!", "Try again later...", "error");
                    }
                });
            }
            })
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/carmana1/invitro.carmanautos.co.ke/resources/views/app/place_order.blade.php ENDPATH**/ ?>