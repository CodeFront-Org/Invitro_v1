<!--Header Sections-->

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.header','data' => ['label' => $label]]); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

<!--End Header Section -->

<?php echo $__env->yieldContent('css'); ?>
<?php echo $__env->yieldContent('modals'); ?>
    <!-- Begin page -->
    <div id="wrapper">

        <!-- Topbar Start -->

            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.topbarnav','data' => ['label' => $label]]); ?>
<?php $component->withName('topbarnav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- end Topbar -->

        <!-- ========== Left Sidebar Start ========== -->
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.leftnavbar','data' => []]); ?>
<?php $component->withName('leftnavbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start Page Content here -->
        <!-- ============================================================== -->

        <div class="content-page">
            <div class="content mt-2">

                <!-- Start Content-->
                    <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- content -->

        <!-- Footer Start -->
             <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.footer','data' => []]); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <!-- end Footer -->

    </div>

    <!-- ============================================================== -->
    <!-- End Page content -->
    <!-- ============================================================== -->

    </div>
    <!-- END wrapper -->
           <!-- Vendor -->
        <script src="<?php echo e(asset('libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/node-waves/waves.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/waypoints/lib/jquery.waypoints.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/jquery.counterup/jquery.counterup.min.js')); ?>"></script>
        <script src="<?php echo e(asset('libs/feather-icons/feather.min.js')); ?>"></script>



        <?php echo $__env->yieldContent('scripts'); ?>


        <!-- Tippy js-->
        <script src="<?php echo e(asset('/libs/tippy.js/tippy.all.min.js')); ?>"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('js/app.min.js')); ?>"></script>


        <!-- Sweet Alerts js -->
        <script src="<?php echo e(asset('libs/sweetalert2/sweetalert2.all.min.js')); ?>"></script>

        <!-- Sweet alert init js-->
        <script src="<?php echo e(asset('js/pages/sweet-alerts.init.js')); ?>"></script>

    <!-- Toastr js -->
    <script src="<?php echo e(asset('libs/toastr/build/toastr.min.js')); ?>"></script>

    <script src="<?php echo e(asset('js/pages/toastr.init.js')); ?>"></script>
    <script>

    </script>

</body>

</html>
<?php /**PATH /home/carmana1/invitro.carmanautos.co.ke/resources/views/layouts/app.blade.php ENDPATH**/ ?>